export { default } from './AuthCard'
